import React, { useState, useEffect } from 'react';
import { View, TextInput, FlatList, Text, TouchableOpacity, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { BASE_URL } from '../config';

export default function FriendRequestScreen({ navigation }) {
  const [searchQuery, setSearchQuery] = useState(''); // State for search input
  const [searchResults, setSearchResults] = useState([]); // State to store user search results
  const [friends, setFriends] = useState([]); // State to store current friends
  const [loggedInUserEmail, setLoggedInUserEmail] = useState(''); // Logged-in user's email
  const [noResults, setNoResults] = useState(false); // State to handle no results

  // Fetch current friends and logged-in user's email on component mount
  useEffect(() => {
    fetchFriendsAndUser();
  }, []);

  const fetchFriendsAndUser = async () => {
    try {
      const token = await AsyncStorage.getItem('jwtToken'); // Retrieve JWT token
      const userEmail = await AsyncStorage.getItem('userEmail'); // Retrieve logged-in user's email

      setLoggedInUserEmail(userEmail); // Save the logged-in user's email

      const response = await axios.get(`${BASE_URL}/api/friends/status`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const acceptedFriends = Object.entries(response.data)
        .filter(([email, status]) => status === 'ACCEPTED')
        .map(([email]) => email);

      setFriends(acceptedFriends); // Save the list of accepted friends
    } catch (error) {
      console.error('Error fetching friends:', error.message);
    }
  };

  // Function to fetch users
  const searchUsers = async (query) => {
    try {
      console.log('Searching for:', query);

      const token = await AsyncStorage.getItem('jwtToken');
      if (!token) {
        alert('User not authenticated. Please log in again.');
        return;
      }

      const response = await axios.get(`${BASE_URL}/api/friends/search`, {
        params: { query: query },
        headers: { Authorization: `Bearer ${token}` },
      });

      console.log('Response data:', response.data); // Log the response

      const filteredResults = response.data.filter(
        (user) => !friends.includes(user.email) && user.email !== loggedInUserEmail // Exclude friends and self
      );

      if (filteredResults.length === 0) {
        setNoResults(true); // Show "No users found" message
      } else {
        setNoResults(false); // Reset "No users found" state
      }

      setSearchResults(filteredResults); // Update state with filtered results
    } catch (error) {
      console.error('Error fetching users:', error.message);
      alert('Error fetching users');
    }
  };

  // Handle search input and validation
  const handleSearch = () => {
    if (!searchQuery.trim()) {
      alert('Please enter a search query');
      return;
    }
    searchUsers(searchQuery.trim());
  };

  return (
    <View style={styles.container}>
      {/* Return to Friends List Button */}
      <TouchableOpacity
        style={styles.returnButton}
        onPress={() => navigation.navigate('FriendList')} // Navigate back to Friend List screen
      >
        <Text style={styles.returnButtonText}>Return to Friends List</Text>
      </TouchableOpacity>

      <TextInput
        style={styles.input}
        placeholder="Search users"
        value={searchQuery}
        onChangeText={setSearchQuery} // Updates searchQuery state
      />
      <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
        <Text style={styles.searchButtonText}>Search</Text>
      </TouchableOpacity>

      {/* Display no results message */}
      {noResults && <Text style={styles.noResultsText}>No users found. This search excludes your friends.</Text>}

      {/* Display search results */}
      <FlatList
        data={searchResults}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.resultItem}>
            <Text>
              {item.name ? `${item.name}` : 'Name not available'} ({item.email ? item.email : 'Email not available'})
            </Text>
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => addFriend(item.email)} // Trigger friend request
            >
              <Text style={styles.addButtonText}>Add</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  returnButton: {
    backgroundColor: '#007bff', // Blue for Return button
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  returnButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  input: { borderWidth: 1, padding: 10, marginBottom: 10, borderRadius: 5 },
  searchButton: {
    backgroundColor: '#4CAF50', // Green for Search button
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  searchButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  noResultsText: { textAlign: 'center', marginTop: 20, color: 'red', fontSize: 16 },
  resultItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 10, borderBottomWidth: 1, borderColor: '#ddd' },
  addButton: { backgroundColor: 'green', paddingVertical: 5, paddingHorizontal: 10, borderRadius: 5 },
  addButtonText: { color: '#fff', fontWeight: 'bold' },
});
