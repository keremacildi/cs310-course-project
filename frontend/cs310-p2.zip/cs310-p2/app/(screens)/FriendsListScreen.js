import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { BASE_URL } from '../config';


export default function FriendListScreen({ navigation }) {
  const [friends, setFriends] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFriendStatuses();
  }, []);

  const fetchFriendStatuses = async () => {
    try {
      const token = await AsyncStorage.getItem('jwtToken');
      const response = await axios.get(`${BASE_URL}/api/friends/status`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const allFriends = response.data;

      // Combine sections into one list with labels
      const formattedData = [
        { type: 'header', title: 'Requests' },
        ...Object.entries(allFriends)
          .filter(([_, status]) => status === 'PENDING' || status === 'REQUESTED')
          .map(([email, status]) => ({ email, status })),
        { type: 'header', title: 'Current Friends' },
        ...Object.entries(allFriends)
          .filter(([_, status]) => status === 'ACCEPTED')
          .map(([email, status]) => ({ email, status })),
      ];

      setFriends(formattedData);
    } catch (error) {
      console.error('Error fetching friend statuses:', error.message);
      alert('Error fetching friend statuses');
    } finally {
      setLoading(false);
    }
  };

  const acceptFriendRequest = async (requesterEmail) => {
    try {
      const token = await AsyncStorage.getItem('jwtToken');
      const userEmail = await AsyncStorage.getItem('userEmail');

      await axios.post(
        `${BASE_URL}/api/friends/accept`,
        { userEmail, requesterEmail },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      alert('Friend request accepted');
      fetchFriendStatuses(); // Refresh list
    } catch (error) {
      console.error('Error accepting friend request:', error.message);
      alert('Failed to accept friend request');
    }
  };

  return (
    <View style={styles.container}>
      {/* Return to Home Button */}
      <TouchableOpacity
        style={styles.homeButton}
        onPress={() => navigation.navigate('Home')}
      >
        <Text style={styles.homeButtonText}>Return to Home</Text>
      </TouchableOpacity>

      <Text style={styles.header}>Friends & Requests</Text>

      {/* Send Friend Request Button */}
      <TouchableOpacity
        style={styles.sendFriendRequestButton}
        onPress={() => navigation.navigate('FriendRequest')}
      >
        <Text style={styles.sendFriendRequestButtonText}>Send Friend Request</Text>
      </TouchableOpacity>

      {loading ? (
        <Text>Loading...</Text>
      ) : (
        <FlatList
          data={friends}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) =>
            item.type === 'header' ? (
              <Text style={styles.sectionHeader}>{item.title}</Text>
            ) : (
              <View style={styles.friendItem}>
                <Text>{item.email}</Text>
                {item.status === 'PENDING' && (
                  <TouchableOpacity
                    style={styles.acceptButton}
                    onPress={() => acceptFriendRequest(item.email)}
                  >
                    <Text style={styles.acceptButtonText}>Accept</Text>
                  </TouchableOpacity>
                )}
                {item.status === 'REQUESTED' && (
                  <Text style={styles.statusTag}>Requested</Text>
                )}
                {item.status === 'ACCEPTED' && (
                  <TouchableOpacity
                    style={styles.chatButton}
                    onPress={() => navigation.navigate('Chat', { friendEmail: item.email })}
                  >
                    <Text style={styles.chatButtonText}>Chat</Text>
                  </TouchableOpacity>
                )}
              </View>
            )
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  homeButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  homeButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  sendFriendRequestButton: {
    backgroundColor: 'gray',
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  sendFriendRequestButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  sectionHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    backgroundColor: '#f0f0f0',
    padding: 8,
    borderRadius: 5,
    marginVertical: 5,
  },
  friendItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#ddd',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  acceptButton: {
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
  },
  acceptButtonText: { color: '#fff', fontWeight: 'bold' },
  statusTag: {
    backgroundColor: '#ffcc00',
    padding: 5,
    borderRadius: 5,
    marginLeft: 10,
    fontWeight: 'bold',
    color: '#333',
  },
  chatButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
  },
  chatButtonText: { color: '#fff', fontWeight: 'bold' },
});
