import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { useFocusEffect } from '@react-navigation/native';
import { BASE_URL } from '../config';

export default function GroupChatScreen({ route, navigation }) {
  const { groupId } = route.params; // Group ID passed from navigation
  const [messages, setMessages] = useState([]); // Message history
  const [newMessage, setNewMessage] = useState(''); // New message input
  const [currentUser, setCurrentUser] = useState(''); // Current user's email
  let interval;

  useFocusEffect(
    React.useCallback(() => {
      fetchCurrentUser();
      fetchMessages();
      interval = setInterval(fetchMessages, 200); // Poll every 200ms for real-time updates

      return () => clearInterval(interval); // Clear interval on screen unfocus
    }, [])
  );

  const fetchCurrentUser = async () => {
    const userEmail = await AsyncStorage.getItem('userEmail');
    setCurrentUser(userEmail); // Set the current user's email
  };

  const fetchMessages = async () => {
    try {
      const token = await AsyncStorage.getItem('jwtToken'); // Retrieve JWT token
      const response = await axios.get(`${BASE_URL}/api/group-messages/${groupId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setMessages(response.data); // Load message history into state
    } catch (error) {
      console.error('Error fetching messages:', error.message);
      alert('Error fetching message history');
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) {
      alert('Message cannot be empty');
      return;
    }

    const token = await AsyncStorage.getItem('jwtToken');
    const userEmail = await AsyncStorage.getItem('userEmail'); // Sender's email

    const message = {
      groupId,
      sender: userEmail,
      content: newMessage.trim(),
    };

    try {
      await axios.post(
        `${BASE_URL}/api/group-messages/send`,
        message,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setNewMessage(''); // Clear input field
    } catch (error) {
      console.error('Error sending message:', error.message);
      alert('Failed to send message');
    }
  };

  return (
    <View style={styles.container}>
      {/* Return to Group List Button */}
      <TouchableOpacity
        style={styles.returnButton}
        onPress={() => navigation.navigate('GroupList')} // Navigate back to Group List screen
      >
        <Text style={styles.returnButtonText}>Return to Group List</Text>
      </TouchableOpacity>

      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View
            style={[
              styles.messageItem,
              item.sender === currentUser ? styles.sent : styles.received,
            ]}
          >
            <Text style={styles.messageSender}>{item.sender}</Text>
            <Text>{item.content}</Text>
          </View>
        )}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Type a message"
          value={newMessage}
          onChangeText={setNewMessage}
          onSubmitEditing={sendMessage} // Trigger sendMessage when Enter key is pressed
          blurOnSubmit={false} // Prevent input from losing focus after submission
        />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
          <Text style={styles.sendButtonText}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  returnButton: {
    backgroundColor: '#007bff', // Blue for Return button
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  returnButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  messageItem: { padding: 10, marginBottom: 10, borderRadius: 5 },
  received: { backgroundColor: '#f1f1f1', alignSelf: 'flex-start' }, // Left side
  sent: { backgroundColor: '#d1f0d1', alignSelf: 'flex-end' }, // Right side
  messageSender: { fontWeight: 'bold', marginBottom: 5 },
  inputContainer: { flexDirection: 'row', alignItems: 'center', padding: 10 },
  input: { flex: 1, borderWidth: 1, padding: 10, borderRadius: 5, marginRight: 10 },
  sendButton: {
    backgroundColor: '#4CAF50', // Green for Send button
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  sendButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
