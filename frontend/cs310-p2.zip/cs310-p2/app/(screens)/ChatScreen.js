import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { useFocusEffect } from '@react-navigation/native';
import { BASE_URL } from '../config';


export default function ChatScreen({ route, navigation }) {
  const { friendEmail } = route.params; // Get friend's email from navigation params
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  let interval;

  useFocusEffect(
    React.useCallback(() => {
      fetchConversation();
      interval = setInterval(fetchConversation, 200); // Start polling when screen is focused

      return () => clearInterval(interval); // Clear interval when screen loses focus
    }, [])
  );

  const fetchConversation = async () => {
    try {
      const token = await AsyncStorage.getItem('jwtToken');
      const userEmail = await AsyncStorage.getItem('userEmail'); // Get logged-in user's email

      const response = await axios.get(`${BASE_URL}/api/messages`, {
        params: { userEmail, friendEmail },
        headers: { Authorization: `Bearer ${token}` },
      });

      setMessages(response.data); // Update conversation messages
    } catch (error) {
      console.error('Error fetching conversation:', error.message);
      alert('Failed to fetch conversation');
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) {
      alert('Message cannot be empty');
      return;
    }

    try {
      const token = await AsyncStorage.getItem('jwtToken');
      const userEmail = await AsyncStorage.getItem('userEmail');

      await axios.post(
        `${BASE_URL}/api/messages/send`,
        {
          senderEmail: userEmail,
          receiverEmail: friendEmail,
          content: newMessage.trim(),
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setNewMessage(''); // Clear input after sending
      fetchConversation(); // Refresh conversation
    } catch (error) {
      console.error('Error sending message:', error.message);
      alert('Failed to send message');
    }
  };

  return (
    <View style={styles.container}>
      {/* Return to Friends List Button */}
      <TouchableOpacity
        style={styles.returnButton}
        onPress={() => navigation.navigate('FriendList')} // Navigate to FriendList screen
      >
        <Text style={styles.returnButtonText}>Return to Friends List</Text>
      </TouchableOpacity>

      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View
            style={[
              styles.messageItem,
              item.senderEmail === friendEmail ? styles.received : styles.sent,
            ]}
          >
            <Text>{item.content}</Text>
          </View>
        )}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Type a message"
          value={newMessage}
          onChangeText={setNewMessage}
          onSubmitEditing={sendMessage} // Trigger sendMessage on Enter key
          blurOnSubmit={false} // Prevent input from losing focus after submission
        />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
          <Text style={styles.sendButtonText}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  returnButton: {
    backgroundColor: '#007bff', // Blue for Return button
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  returnButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  messageItem: { padding: 10, marginBottom: 10, borderRadius: 5 },
  received: { backgroundColor: '#f1f1f1', alignSelf: 'flex-start' },
  sent: { backgroundColor: '#d1f0d1', alignSelf: 'flex-end' },
  inputContainer: { flexDirection: 'row', alignItems: 'center', padding: 10 },
  input: { flex: 1, borderWidth: 1, padding: 10, borderRadius: 5, marginRight: 10 },
  sendButton: {
    backgroundColor: '#4CAF50', // Green for Send button
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  sendButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
