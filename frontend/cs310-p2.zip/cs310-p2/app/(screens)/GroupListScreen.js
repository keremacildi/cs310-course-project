import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { BASE_URL } from '../config';

export default function GroupListScreen({ navigation }) {
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchGroups();
  }, []);

  const fetchGroups = async () => {
    try {
      const token = await AsyncStorage.getItem('jwtToken'); // Retrieve JWT token
      const userEmail = await AsyncStorage.getItem('userEmail'); // Retrieve logged-in user email
  
      const response = await axios.get(`${BASE_URL}/api/groups`, {
        params: { userEmail },
        headers: { Authorization: `Bearer ${token}` },
      });
  
      // Check if response data is valid and set groups appropriately
      if (response.data && Array.isArray(response.data)) {
        setGroups(response.data);
      } else {
        setGroups([]); // Fallback to an empty array if response is invalid
      }
    } catch (error) {
      console.error('Error fetching groups:', error.message);
      alert('Error fetching groups');
      setGroups([]); // Ensure groups are empty if an error occurs
    } finally {
      setLoading(false);
    }
  };
  

  return (
    <View style={styles.container}>
      {/* Return to Home Button */}
      <TouchableOpacity
        style={styles.returnButton}
        onPress={() => navigation.navigate('Home')} // Navigate back to Home screen
      >
        <Text style={styles.returnButtonText}>Return to Home</Text>
      </TouchableOpacity>

      <Text style={styles.header}>Groups</Text>

      {/* Create Group Button */}
      <TouchableOpacity
        style={styles.createGroupButton}
        onPress={() => navigation.navigate('CreateGroup')}
      >
        <Text style={styles.createGroupButtonText}>Create Group</Text>
      </TouchableOpacity>

      {/* Group List */}
      {loading ? (
        <Text>Loading...</Text>
      ) : groups.length === 0 ? (
        <Text style={styles.noGroupsText}>You are not part of any groups</Text>
      ) : (
        <FlatList
          data={groups}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={styles.groupItem}>
              <Text style={styles.groupName}>{item.name}</Text>
              <Text style={styles.groupAdmin}>Admin: {item.admin}</Text>

              {/* Info Button */}
              <TouchableOpacity
                style={styles.infoButton}
                onPress={() => navigation.navigate('GroupDetails', { groupId: item.id })}
              >
                <Text style={styles.infoButtonText}>Info</Text>
              </TouchableOpacity>

              {/* Chat Button */}
              <TouchableOpacity
                style={styles.chatButton}
                onPress={() => navigation.navigate('GroupChat', { groupId: item.id })}
              >
                <Text style={styles.chatButtonText}>Chat</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  returnButton: {
    backgroundColor: '#007bff', // Green for Return button
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  returnButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  createGroupButton: {
    backgroundColor: 'gray',
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  createGroupButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  noGroupsText: { textAlign: 'center', marginTop: 20, fontSize: 16, color: 'gray' },
  groupItem: {
    padding: 15,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#f9f9f9',
  },
  groupName: { fontSize: 18, fontWeight: 'bold' },
  groupAdmin: { fontSize: 14, color: 'gray' },
  infoButton: {
    backgroundColor: '#4CAF50', // Green for Info
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    alignItems: 'center',
  },
  infoButtonText: { color: '#fff', fontWeight: 'bold' },
  chatButton: {
    backgroundColor: 'blue', // Blue for Chat
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  chatButtonText: { color: '#fff', fontWeight: 'bold' },
});
