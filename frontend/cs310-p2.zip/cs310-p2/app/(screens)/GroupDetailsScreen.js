import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { BASE_URL } from '../config';

export default function GroupDetailsScreen({ route, navigation }) {
  const { groupId } = route.params; // Retrieve groupId from route params
  const [group, setGroup] = useState(null);

  useEffect(() => {
    fetchGroupDetails();
  }, []);

  const fetchGroupDetails = async () => {
    try {
      const token = await AsyncStorage.getItem('jwtToken'); // Retrieve JWT token
      const response = await axios.get(`${BASE_URL}/api/groups/${groupId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setGroup(response.data);
    } catch (error) {
      console.error('Error fetching group details:', error.message);
      alert('Error fetching group details');
    }
  };

  if (!group) {
    return <Text>Loading...</Text>;
  }

  return (
    <View style={styles.container}>
      {/* Return to Group List Button */}
      <TouchableOpacity
        style={styles.returnButton}
        onPress={() => navigation.navigate('GroupList')} // Navigate back to Group List screen
      >
        <Text style={styles.returnButtonText}>Return to Group List</Text>
      </TouchableOpacity>

      <Text style={styles.header}>{group.name}</Text>
      <Text>Created By: {group.admin}</Text>
      <Text>Created At: {group.createdAt ? new Date(group.createdAt).toLocaleString() : 'N/A'}</Text>

      <Text style={styles.subHeader}>Members</Text>
      <FlatList
        data={group.members}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => <Text style={styles.memberItem}>{item}</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  returnButton: {
    backgroundColor: '#007bff', // Blue for Return button
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  returnButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  subHeader: { fontSize: 18, fontWeight: 'bold', marginVertical: 10 },
  memberItem: { fontSize: 16, paddingVertical: 5 },
});
