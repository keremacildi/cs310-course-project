import React, { useState, useEffect } from 'react';
import { View, TextInput, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { BASE_URL } from '../config';



export default function CreateGroupScreen({ navigation }) {
  const [groupName, setGroupName] = useState(''); // State for group name
  const [friends, setFriends] = useState([]); // State for user's friends
  const [selectedMembers, setSelectedMembers] = useState([]); // State for selected group members
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFriends(); // Fetch friends when screen loads
  }, []);

  const fetchFriends = async () => {
    try {
      const token = await AsyncStorage.getItem('jwtToken'); // Retrieve JWT token
      const userEmail = await AsyncStorage.getItem('userEmail'); // Retrieve logged-in user email
      const response = await axios.get(`${BASE_URL}/api/friends?userEmail=${userEmail}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setFriends(response.data);
    } catch (error) {
      console.error('Error fetching friends:', error.message);
      alert('Error fetching friends');
    } finally {
      setLoading(false);
    }
  };

  const toggleMemberSelection = (email) => {
    if (selectedMembers.includes(email)) {
      setSelectedMembers(selectedMembers.filter((member) => member !== email));
    } else {
      setSelectedMembers([...selectedMembers, email]);
    }
  };

  const createGroup = async () => {
    if (!groupName.trim()) {
      alert('Please enter a group name');
      return;
    }

    if (selectedMembers.length === 0) {
      alert('Please select at least one member');
      return;
    }

    try {
      const token = await AsyncStorage.getItem('jwtToken'); // Retrieve JWT token
      const userEmail = await AsyncStorage.getItem('userEmail'); // Retrieve logged-in user email

      const response = await axios.post(
        `${BASE_URL}/api/groups/create`,
        {
          groupName,
          adminEmail: userEmail,
          members: selectedMembers,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      alert('Group created successfully');
      setGroupName(''); // Reset group name
      setSelectedMembers([]); // Reset selected members
      navigation.navigate('GroupList'); // Navigate back to group list
    } catch (error) {
      console.error('Error creating group:', error.message);
      alert('Failed to create group');
    }
  };

  return (
    <View style={styles.container}>
      {/* Return to Group List Button */}
      <TouchableOpacity
        style={styles.returnButton}
        onPress={() => navigation.navigate('GroupList')} // Navigate back to Group List screen
      >
        <Text style={styles.returnButtonText}>Return to Group List</Text>
      </TouchableOpacity>

      <Text style={styles.header}>Create Group</Text>

      <TextInput
        style={styles.input}
        placeholder="Enter group name"
        value={groupName}
        onChangeText={setGroupName}
      />

      <Text style={styles.subHeader}>Select Members</Text>
      {loading ? (
        <Text>Loading friends...</Text>
      ) : friends.length === 0 ? (
        <Text>No friends available</Text>
      ) : (
        <FlatList
          data={friends}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.friendItem,
                selectedMembers.includes(item) && styles.selectedFriend,
              ]}
              onPress={() => toggleMemberSelection(item)}
            >
              <Text style={styles.friendText}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      )}

      <TouchableOpacity style={styles.createGroupButton} onPress={createGroup}>
        <Text style={styles.createGroupButtonText}>Create Group</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  returnButton: {
    backgroundColor: '#007bff', // Blue for Return button
    padding: 10,
    borderRadius: 5,
    marginBottom: 16,
    alignItems: 'center',
  },
  returnButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  subHeader: { fontSize: 18, fontWeight: 'bold', marginTop: 20, marginBottom: 10 },
  input: { borderWidth: 1, padding: 10, marginBottom: 10, borderRadius: 5 },
  friendItem: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 5,
    borderRadius: 5,
  },
  selectedFriend: { backgroundColor: 'gray', borderColor: '#007bff' },
  friendText: { color: '#000' },
  createGroupButton: {
    backgroundColor: '#4CAF50', // Green for Create Group button
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
    alignItems: 'center',
  },
  createGroupButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
