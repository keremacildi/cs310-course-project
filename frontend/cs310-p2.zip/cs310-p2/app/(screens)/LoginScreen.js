import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BASE_URL } from '../config';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

const handleLogin = async () => {
  try {
    const response = await axios.post(`${BASE_URL}/api/login`, {
      email,
      password,
    });

    const { token, userEmail } = response.data; // Extract token and email
    console.log('Login successful:', { token, userEmail });

    // Store the token and email in AsyncStorage
    await AsyncStorage.setItem('jwtToken', token);
    await AsyncStorage.setItem('userEmail', userEmail);
    navigation.navigate('Home');
  } catch (error) {
    console.error('Login failed:', error.message);
    alert('Login failed');
  }
};

  

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput placeholder="Email" onChangeText={setEmail} style={styles.input} keyboardType="email-address" />
      <TextInput placeholder="Password" onChangeText={setPassword} style={styles.input} secureTextEntry />
      <Button title="Login" onPress={handleLogin} />
      <Button title="Go to Register" onPress={() => navigation.navigate('Register')} color="gray" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 16 },
  title: { fontSize: 24, marginBottom: 20, textAlign: 'center' },
  input: { borderWidth: 1, marginBottom: 10, padding: 8, borderRadius: 5 }
});
