//npm install @react-native-async-storage/async-storage
//npm install axios
//npm install @react-navigation/native @react-navigation/stack react-native-screens react-native-safe-area-context


//Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
//npx expo start

import React from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import ChatScreen from './(screens)/ChatScreen';
import CreateGroupScreen from './(screens)/CreateGroupScreen';
import FriendRequestScreen from './(screens)/FriendRequestScreen';
import FriendsListScreen from './(screens)/FriendsListScreen';
import GroupChatScreen from './(screens)/GroupChatScreen';
import GroupDetailsScreen from './(screens)/GroupDetailsScreen';
import GroupListScreen from './(screens)/GroupListScreen';
import HomeScreen from './(screens)/HomeScreen';
import LoginScreen from './(screens)/LoginScreen';
import RegisterScreen from './(screens)/RegisterScreen';

const Stack = createStackNavigator();

export default function Index() {
  return (
    <Stack.Navigator
      initialRouteName="Login"
      screenOptions={{headerShown: false,}}
    >
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="FriendList" component={FriendsListScreen} />
      <Stack.Screen name="GroupList" component={GroupListScreen} />
      <Stack.Screen name="FriendRequest" component={FriendRequestScreen} />
      <Stack.Screen name="CreateGroup" component={CreateGroupScreen} />
      <Stack.Screen
        name="Chat"
        component={ChatScreen}
        options={({ route }) => ({
          title: `Chat with ${route.params.friendEmail}`, // Dynamic title
        })}
      />
      <Stack.Screen name="GroupDetails" component={GroupDetailsScreen} />
      <Stack.Screen name="GroupChat" component={GroupChatScreen} />

    </Stack.Navigator>
  );
}
