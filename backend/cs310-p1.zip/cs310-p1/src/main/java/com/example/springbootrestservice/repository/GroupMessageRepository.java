package com.example.springbootrestservice.repository;

import com.example.springbootrestservice.model.GroupMessage;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface GroupMessageRepository extends MongoRepository<GroupMessage, String> {
    List<GroupMessage> findByGroupIdOrderByTimestampAsc(String groupId); // Fetch messages for a group, sorted by timestamp
}
