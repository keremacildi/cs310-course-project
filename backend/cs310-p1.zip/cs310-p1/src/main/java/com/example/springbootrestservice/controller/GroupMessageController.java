package com.example.springbootrestservice.controller;

import com.example.springbootrestservice.model.GroupMessage;
import com.example.springbootrestservice.repository.GroupMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Date; // Add this import at the top of your file


@RestController
@RequestMapping("/api/group-messages")
public class GroupMessageController {

    @Autowired
    private GroupMessageRepository groupMessageRepository;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    // Send a message to the group
    @PostMapping("/send")
    public ResponseEntity<?> sendMessage(@RequestBody GroupMessage groupMessage) {
        groupMessage.setTimestamp(new Date()); // Ensure timestamp is set
        groupMessageRepository.save(groupMessage);

        // Broadcast the message in real-time using WebSocket
        messagingTemplate.convertAndSend("/topic/group/" + groupMessage.getGroupId(), groupMessage);

        return ResponseEntity.ok("Message sent successfully");
    }



    // Fetch message history for a group
    @GetMapping("/{groupId}")
    public ResponseEntity<?> getGroupMessages(@PathVariable String groupId) {
        List<GroupMessage> messages = groupMessageRepository.findByGroupIdOrderByTimestampAsc(groupId);
        return ResponseEntity.ok(messages);
    }
}
