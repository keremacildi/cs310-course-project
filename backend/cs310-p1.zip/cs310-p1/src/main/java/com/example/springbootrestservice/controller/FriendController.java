package com.example.springbootrestservice.controller;

import com.example.springbootrestservice.model.User;
import com.example.springbootrestservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;
import java.util.List;
import com.example.springbootrestservice.util.JwtUtil;
import java.util.stream.Collectors; // For Collectors
import java.util.Collections;      // For Collections.emptyList()
import java.util.HashMap;


@RestController
@RequestMapping("/api/friends")
@CrossOrigin(origins = "*")

public class FriendController {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;

    // Search Users by email or name
    @GetMapping("/search")
    public ResponseEntity<?> searchUsers(@RequestParam String query) {
        List<User> users = userRepository.findByEmailContainingIgnoreCaseOrNameContainingIgnoreCase(query, query);

        List<Map<String, String>> userResults = users.stream()
                .map(user -> Map.of(
                        "name", user.getName(),
                        "email", user.getEmail()
                ))
                .collect(Collectors.toList());

        if (userResults.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList());
        }

        return ResponseEntity.ok(userResults);
    }



    @PostMapping("/add")
    public ResponseEntity<?> sendFriendRequest(@RequestBody Map<String, String> payload, @RequestHeader("Authorization") String token) {
        String toEmail = payload.get("toEmail");
        String fromEmail = jwtUtil.extractEmail(token.substring(7)); // Extract the sender's email from the token

        // Check if the sender is trying to send a request to themselves
        if (fromEmail.equals(toEmail)) {
            return ResponseEntity.badRequest().body("You cannot send a friend request to yourself.");
        }

        Optional<User> fromUser = userRepository.findByEmail(fromEmail);
        Optional<User> toUser = userRepository.findByEmail(toEmail);

        if (fromUser.isEmpty() || toUser.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid user email(s).");
        }

        User receiver = toUser.get();

        // Check if a request has already been sent
        if (receiver.getFriendRequests().contains(fromEmail)) {
            return ResponseEntity.badRequest().body("Friend request already sent.");
        }

        // Add the friend request
        receiver.getFriendRequests().add(fromEmail);
        userRepository.save(receiver);

        return ResponseEntity.ok(Map.of(
                "status", "PENDING",
                "message", "Friend request sent successfully."
        ));
    }




    // Accept a friend request
    @PostMapping("/accept")
    public ResponseEntity<?> acceptFriendRequest(@RequestBody Map<String, String> payload) {
        String userEmail = payload.get("userEmail");
        String requesterEmail = payload.get("requesterEmail");

        if (userEmail == null || requesterEmail == null) {
            return ResponseEntity.badRequest().body("Both fromEmail and toEmail are required");
        }

        Optional<User> user = userRepository.findByEmail(userEmail);
        Optional<User> requester = userRepository.findByEmail(requesterEmail);

        if (user.isEmpty() || requester.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid user email(s)");
        }

        User u = user.get();
        if (!u.getFriendRequests().contains(requesterEmail)) {
            return ResponseEntity.badRequest().body("No friend request from this user");
        }

        // Remove from friend requests and add to friends
        u.getFriendRequests().remove(requesterEmail);
        u.getFriends().add(requesterEmail);
        userRepository.save(u);

        User req = requester.get();
        req.getFriends().add(userEmail);
        userRepository.save(req);

        return ResponseEntity.ok("Friend request accepted");
    }

    // Get the friend list
    @GetMapping
    public ResponseEntity<?> getFriends(@RequestParam String userEmail) {
        System.out.println("Fetching friends for user: " + userEmail);
        Optional<User> user = userRepository.findByEmail(userEmail);

        if (user.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        return ResponseEntity.ok(user.get().getFriends());
    }

    @GetMapping("/status")
    public ResponseEntity<?> getFriendRequests(@RequestHeader("Authorization") String token) {
        String userEmail = jwtUtil.extractEmail(token.substring(7)); // Extract user from token

        Optional<User> user = userRepository.findByEmail(userEmail);
        if (user.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        User currentUser = user.get();
        Map<String, String> friendRequestStatus = new HashMap<>();

        // Incoming requests (requests received by the user)
        currentUser.getFriendRequests().forEach(requester -> {
            friendRequestStatus.put(requester, "PENDING");
        });

        // Outgoing requests (requests sent by the user)
        List<User> allUsers = userRepository.findAll();
        for (User u : allUsers) {
            if (u.getFriendRequests().contains(userEmail)) {
                friendRequestStatus.put(u.getEmail(), "REQUESTED");
            }
        }

        // Accepted friends
        currentUser.getFriends().forEach(friend -> {
            friendRequestStatus.put(friend, "ACCEPTED");
        });

        return ResponseEntity.ok(friendRequestStatus);
    }





}
