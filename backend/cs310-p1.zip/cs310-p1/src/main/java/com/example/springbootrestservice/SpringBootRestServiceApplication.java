package com.example.springbootrestservice;

import com.example.springbootrestservice.model.Group;
import com.example.springbootrestservice.repository.GroupRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringBootRestServiceApplication {
    @Autowired
    private GroupRepository groupRepository;

    public static void main(String[] args) {
        SpringApplication.run(SpringBootRestServiceApplication.class, args);
    }

    @PostConstruct
    public void initializeGroupCounter() {
        int maxId = groupRepository.findAll().stream()
                .mapToInt(Group::getId)
                .max()
                .orElse(0);
        Group.setCounter(maxId + 1); // Initialize counter to maxId + 1
        System.out.println("Group ID counter initialized to: " + (maxId + 1));
    }
}

