package com.example.springbootrestservice.controller;

import com.example.springbootrestservice.model.Message;
import com.example.springbootrestservice.model.User;
import com.example.springbootrestservice.repository.MessageRepository;
import com.example.springbootrestservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SimpMessagingTemplate messagingTemplate; // For WebSocket messaging

    // Send a message
    @PostMapping("/send")
    public ResponseEntity<?> sendMessage(@RequestBody Message message) {
        Optional<User> sender = userRepository.findByEmail(message.getSenderEmail());
        Optional<User> receiver = userRepository.findByEmail(message.getReceiverEmail());

        if (sender.isEmpty() || receiver.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid sender or receiver email");
        }

        if (!sender.get().getFriends().contains(message.getReceiverEmail())) {
            return ResponseEntity.badRequest().body("Users are not friends");
        }

        messageRepository.save(message);

        // Broadcast the message in real-time using WebSocket
        messagingTemplate.convertAndSend("/topic/messages/" + message.getReceiverEmail(), message);

        return ResponseEntity.ok("Message sent successfully");
    }

    // Retrieve conversation between two users
    @GetMapping
    public ResponseEntity<?> getConversation(@RequestParam String userEmail, @RequestParam String friendEmail) {
        Optional<User> user = userRepository.findByEmail(userEmail);

        if (user.isEmpty() || !user.get().getFriends().contains(friendEmail)) {
            return ResponseEntity.badRequest().body("Users are not friends");
        }

        List<Message> sentMessages = messageRepository.findBySenderEmailAndReceiverEmail(userEmail, friendEmail);
        List<Message> receivedMessages = messageRepository.findByReceiverEmailAndSenderEmail(userEmail, friendEmail);

        List<Message> conversation = new ArrayList<>();
        conversation.addAll(sentMessages);
        conversation.addAll(receivedMessages);
        conversation.sort((m1, m2) -> m1.getTimestamp().compareTo(m2.getTimestamp()));

        return ResponseEntity.ok(conversation);
    }
}
