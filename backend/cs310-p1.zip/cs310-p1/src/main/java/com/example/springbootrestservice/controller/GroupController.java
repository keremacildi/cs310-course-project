package com.example.springbootrestservice.controller;

import com.example.springbootrestservice.model.Group;
import com.example.springbootrestservice.repository.GroupRepository;
import com.example.springbootrestservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/groups")
public class GroupController {

    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private UserRepository userRepository;

    // Create a new group
    @PostMapping("/create")
    public ResponseEntity<?> createGroup(@RequestBody Map<String, Object> request) {
        String groupName = (String) request.get("groupName");
        String adminEmail = (String) request.get("adminEmail");
        List<String> members = (List<String>) request.get("members");

        if (groupName == null || groupName.isEmpty() || adminEmail == null || adminEmail.isEmpty()) {
            return ResponseEntity.badRequest().body("Group name and admin email are required");
        }

        if (!userRepository.findByEmail(adminEmail).isPresent()) {
            return ResponseEntity.badRequest().body("Admin email not found");
        }

        Group group = new Group(groupName, adminEmail);

        for (String memberEmail : members) {
            if (!userRepository.findByEmail(memberEmail).isPresent()) {
                return ResponseEntity.badRequest().body("User with email " + memberEmail + " does not exist");
            }
            group.getMembers().add(memberEmail);
        }

        groupRepository.save(group);
        return ResponseEntity.ok("Group created successfully with ID: " + group.getId());
    }

    // Add a member to a group
    @PostMapping("/{groupId}/add-member")
    public ResponseEntity<?> addMember(@PathVariable int groupId, @RequestParam String memberEmail) {
        Optional<Group> groupOptional = groupRepository.findById(groupId);

        if (groupOptional.isEmpty()) {
            return ResponseEntity.badRequest().body("Group not found");
        }

        Group group = groupOptional.get();

        if (group.getMembers().contains(memberEmail)) {
            return ResponseEntity.badRequest().body("Member already exists in the group");
        }

        if (!userRepository.findByEmail(memberEmail).isPresent()) {
            return ResponseEntity.badRequest().body("User with the provided email does not exist");
        }

        group.getMembers().add(memberEmail);
        groupRepository.save(group);
        return ResponseEntity.ok("Member added successfully");
    }

    // Get all groups for a specific admin
    @GetMapping("/my-groups")
    public ResponseEntity<?> getGroupsByAdmin(@RequestParam String adminEmail) {
        List<Group> groups = groupRepository.findByAdmin(adminEmail);

        if (groups.isEmpty()) {
            return ResponseEntity.ok("No groups found for admin " + adminEmail);
        }

        return ResponseEntity.ok(groups);
    }



    // Get all groups for a specific user
    @GetMapping
    public ResponseEntity<?> getGroupsForUser(@RequestParam String userEmail) {
        List<Group> userGroups = groupRepository.findAll().stream()
                .filter(group -> group.getMembers().contains(userEmail) || group.getAdmin().equals(userEmail))
                .collect(Collectors.toList());

        if (userGroups.isEmpty()) {
            return ResponseEntity.ok("No groups found for user " + userEmail);
        }

        return ResponseEntity.ok(userGroups);
    }

    @GetMapping("/{groupId}")
    public ResponseEntity<?> getGroupDetails(@PathVariable int groupId) {
        Optional<Group> groupOptional = groupRepository.findById(groupId);

        if (groupOptional.isEmpty()) {
            return ResponseEntity.badRequest().body("Group not found");
        }

        return ResponseEntity.ok(groupOptional.get());
    }


}
