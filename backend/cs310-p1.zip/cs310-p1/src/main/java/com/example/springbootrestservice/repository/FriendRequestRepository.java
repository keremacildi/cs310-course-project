package com.example.springbootrestservice.repository;

public interface FriendRequestRepository {
}
