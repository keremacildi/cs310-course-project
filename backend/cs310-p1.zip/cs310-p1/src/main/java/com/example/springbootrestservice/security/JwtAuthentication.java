package com.example.springbootrestservice.security;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;

public class JwtAuthentication extends AbstractAuthenticationToken {

    private final UserDetails userDetails;
    private final String token;

    public JwtAuthentication(UserDetails userDetails, String token) {
        super(userDetails.getAuthorities());
        this.userDetails = userDetails;
        this.token = token;
        setAuthenticated(true); // Marks the authentication as successful
    }

    @Override
    public Object getCredentials() {
        return token; // The JWT token itself
    }

    @Override
    public Object getPrincipal() {
        return userDetails; // The authenticated user
    }
}
