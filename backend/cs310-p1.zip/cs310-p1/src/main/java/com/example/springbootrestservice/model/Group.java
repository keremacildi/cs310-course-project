package com.example.springbootrestservice.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;

@Document(collection = "groups")
public class Group {

    @Id
    private int id; // Unique identifier for the group
    private String name; // Group name
    private String admin; // Email of the admin/creator
    private Set<String> members = new HashSet<>(); // Set of member emails

    private static int counter = 1; // Static counter for incremental IDs

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt; // Timestamp for when the group was created

    // Default Constructor
    public Group() {
        // Default constructor for frameworks like Jackson or Spring Data
    }

    // Constructor with parameters
    public Group(String name, String admin) {
        this.id = counter++;
        this.name = name;
        this.admin = admin;
        this.members.add(admin); // Automatically add admin to the group
        this.createdAt = LocalDateTime.now(); // Set the timestamp when the group is created
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public Set<String> getMembers() {
        return members;
    }

    public void setMembers(Set<String> members) {
        this.members = members;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt; // Allow setting this field manually if needed
    }

    // Static counter setter
    public static void setCounter(int newCounter) {
        counter = newCounter;
    }

    public static int getCounter() {
        return counter;
    }
}
