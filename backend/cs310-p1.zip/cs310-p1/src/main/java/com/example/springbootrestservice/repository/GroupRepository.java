package com.example.springbootrestservice.repository;

import com.example.springbootrestservice.model.Group;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface GroupRepository extends MongoRepository<Group, String> {
    Optional<Group> findById(int groupId);

    List<Group> findByAdmin(String adminEmail);
}
