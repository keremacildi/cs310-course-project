package com.example.springbootrestservice.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Document(collection = "users") // Marks this class as a MongoDB document
public class User {

    @Id
    private String id; // MongoDB will use this as the primary key
    private String name;
    private String lastName;
    private String email;
    private String password; // Store the hashed password here

    private Set<String> friendRequests = new HashSet<>();
    private Set<String> friends = new HashSet<>();

    // Default Constructor
    public User() {
    }

    // Constructor with parameters
    public User(String name, String lastName, String email, String password) {
        this.name = name;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Collection<String> getFriendRequests() {
        return friendRequests;
    }

    public Collection<String> getFriends() {
        return friends;
    }
}
